package com.cg.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.beans.Address;
import com.cg.beans.User;
import com.cg.dao.RegisterDao;

@Service
public class RegisterServicesImpl implements RegisterServices {
	@Autowired
	RegisterDao registerDao;
	 static int num=100;
	static int num1=100;

	public RegisterDao getRegisterDao() {
		return registerDao;
	}
	public void setRegisterDao(RegisterDao registerDao) {
		this.registerDao = registerDao;
	}

	public static  int getNum() {
		return ++num;
	}
	public static int getNum1() {
		return ++num1;
	}
	
	
	@Override
	public User addUser(User register) {
		StringBuilder str=new StringBuilder();
		str.append("U"+getNum());
	
		register.setUser_id(str.toString());
		System.out.println(str);
		register.setUser_type("customer");
	
		return registerDao.addUser(register);

	}
	@Override
	public Address addAddress(Address address,User user) {

	
StringBuilder str2=new StringBuilder();
		str2.append("A"+getNum1());
		address.setAddress_id(str2.toString());
		address.setCountry("India");
		address.setUser(user);


		return registerDao.addAddress(address);
	}

}

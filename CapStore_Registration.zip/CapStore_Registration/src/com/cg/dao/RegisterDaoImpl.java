package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;
import com.cg.beans.Address;
import com.cg.beans.User;

@Repository															
@Transactional		
public class RegisterDaoImpl implements RegisterDao{

	@PersistenceContext															
	EntityManager entityManager=null;

	public EntityManager getEntityManager() {
		return entityManager;
	}
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public User addUser(User register) {
		entityManager.persist(register);
		entityManager.flush();
		return register;
	}
	@Override
	public Address addAddress(Address address) {
		entityManager.persist(address);
		entityManager.flush();
		return address;
	}
	


}

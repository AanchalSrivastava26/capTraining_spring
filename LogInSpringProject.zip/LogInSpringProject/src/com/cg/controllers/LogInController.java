package com.cg.controllers;

import java.time.LocalDate;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("LogInController")
public class LogInController {
	@RequestMapping(value="/logIn")
	public ModelAndView showMessage() {
		
		return new ModelAndView("LogIn");


	}
}

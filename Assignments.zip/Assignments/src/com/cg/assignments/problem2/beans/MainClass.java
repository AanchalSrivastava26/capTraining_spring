package com.cg.assignments.problem2.beans;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class MainClass {
	public static void main(String[] args) {
		System.out.println("-------SBU details------");
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("cg2.xml");
		SBU sbu=(SBU)applicationContext.getBean("aanchalObject");
		System.out.println(sbu.getSbuId()+" "+sbu.getSbuName()+" "+sbu.getSbuHead());
		System.out.println("-------employee details-----");
		System.out.println("ID :"+sbu.getEmpList());
}
}
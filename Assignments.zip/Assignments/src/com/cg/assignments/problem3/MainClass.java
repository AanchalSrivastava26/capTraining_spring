package com.cg.assignments.problem3;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("cg3.xml");
		Employee employee=(Employee)applicationContext.getBean("aanchalEmp");
		System.out.println("--------emp info-------");
		System.out.println(employee);
	}
}

package com.cg.assignments.problem4;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class MainClass {
	public static void main(String[] args) {
		Resource resources=new ClassPathResource("cg4.xml");
		BeanFactory beanFactory=new XmlBeanFactory(resources);
		System.out.println("------setter injection-------");
		System.out.println("emp info :");
		Employee emp=(Employee)beanFactory.getBean("obj1");
		System.out.println("employee name :"+" "+emp.getEmployeeName());
		//constructor dependency injection
		System.out.println("------constructor dependency injection-------");
		System.out.println("emp info :");
		Employee emp1=(Employee)beanFactory.getBean("obj2");
		emp1.showDetails();
	}
}

package com.cg.traineeassignment.controllers;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import com.cg.traineeassignment.beans.LogIn;
import com.cg.traineeassignment.beans.TraineeRegister;
import com.cg.traineeassignment.services.TraineeServices;

@Controller
public class LoginController {
	@Autowired
	TraineeServices traineeServices;
	ArrayList<String>domainList=null;

	public TraineeServices getTraineeServices() {
		return traineeServices;
	}
	public void setTraineeServices(TraineeServices traineeService) {
		this.traineeServices = traineeService;
	}
	/*@RequestMapping(value="/logIn",method=RequestMethod.GET) 
	public String showMessage(Model model) {											

		LogIn login=new LogIn();
		model.addAttribute("log",login);
		model.addAttribute("compNameObj","capgemini");
		return "LogIn";
	}*/
	@RequestMapping(value="/ValidateUser" ,method=RequestMethod.POST)
	public String validateUserDetails(BindingResult result,Model model,@RequestParam("userName")String userName,@RequestParam("password")String password) {
	if(traineeServices.isUserExist(userName, password)){
			System.out.println("not in error");
			model.addAttribute("loginSuccess","login successful");
			return "Success";
		}
	
		else {
			System.out.println(" in error");
			model.addAttribute("loginFailed","login failed");
			return "LogIn";
		}
	}

	@ModelAttribute("domainList")
	public ArrayList<String> createTraineeDomainList(){
		ArrayList<String> domainList=new ArrayList<>();
		domainList.add("java");
		domainList.add("crm");
		domainList.add("sales");
		return domainList;

	}
	@RequestMapping(value="/addTrainee",method=RequestMethod.GET)
	public String displayRegisterPage(Model model,@ModelAttribute(value="domainList") ArrayList<String> domainList) {
		model.addAttribute("add", new TraineeRegister());
		model.addAttribute("domainList", domainList);
		return "AddTrainee";
	}
	@RequestMapping(value="/Insert", method=RequestMethod.POST)
	public String addUserDetails(@ModelAttribute(value="add") @Valid TraineeRegister traineeRegister,BindingResult result,Model model) {
		//System.out.println(traineeRegister.getTraineeName());

		//	System.out.println("welcome "+trainee);
		if(result.hasErrors())
			return "AddTrainee";
		else {
			TraineeRegister trainee=traineeServices.addTrainee(traineeRegister);
			model.addAttribute("msg","data is successfully added");
			return "AddTrainee";
		}
	}


	//****delete user


	@RequestMapping(value="/deleteTrainee",method=RequestMethod.GET ) 
	public String showDeleteMessage(@ModelAttribute(value="delete") @Valid TraineeRegister traineeRegister,BindingResult result,Model model) {											

		TraineeRegister register=new TraineeRegister();
		model.addAttribute("delete",register);

		return "Delete";
	}
	@RequestMapping(value="/delete",method=RequestMethod.POST)
	public String deleteUser(@ModelAttribute(value="delete") @Valid TraineeRegister traineeRegister,BindingResult result,Model model) {


		traineeServices.deleteTrainee(traineeRegister.getTraineeId());
		model.addAttribute("msg","data is successfully deleted");

		return "Delete";

	}
	@RequestMapping(value="/retrieveTrainee",method=RequestMethod.GET ) 
	public String showRetrieveMessage( Model model) {
		TraineeRegister register=new TraineeRegister();
		model.addAttribute("retrieve",register);


		return "Retrieve";

	}
	@RequestMapping(value="/retrieve",method=RequestMethod.POST)
	public String retrieveTrainee(@ModelAttribute(value="retrieve") @Valid TraineeRegister traineeRegister,BindingResult result,Model model) {


		model.addAttribute("msg","data is successfully retrieved");
		model.addAttribute("details",traineeServices.retrieveTrainee(traineeRegister.getTraineeId()));

		return "Retrieve";

	}
	@RequestMapping(value="/retrieveAll",method=RequestMethod.GET ) 
	public String showAllRetrieveMessge( Model model) {

		model.addAttribute("msgList",traineeServices.retrieveAllTrainee());
		return "RetrieveAll";
	}

	@RequestMapping(value="/updateTrainee",method=RequestMethod.GET ) 
	public String showUpdateMessage( Model model) {
		TraineeRegister register=new TraineeRegister();
		model.addAttribute("update",register);
		return "Update";
	}
	@RequestMapping(value="/update",method=RequestMethod.POST)
	public String updateTrainee(@ModelAttribute(value="update") @Valid TraineeRegister traineeRegister,BindingResult result,Model model) {

		model.addAttribute("updateDetails",traineeServices.updateTrainee(traineeRegister));
		model.addAttribute("updateMsg","data is successfully updated");


		return "UpdateSuccess";

	}



}

package com.cg.traineeassignment.services;

import java.util.ArrayList;

import com.cg.traineeassignment.beans.LogIn;
import com.cg.traineeassignment.beans.TraineeRegister;

public interface TraineeServices {

	public boolean isUserExist(String userName,String password);
	public ArrayList<TraineeRegister> getAllUserDetails();
	public boolean deleteTrainee(int traineeId);
	public 	TraineeRegister addTrainee(TraineeRegister register);
	public TraineeRegister retrieveTrainee(int traineeId);
	public ArrayList<TraineeRegister> retrieveAllTrainee();
	public TraineeRegister updateTrainee(TraineeRegister traineeRegister);

}

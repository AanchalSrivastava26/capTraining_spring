package com.cg.traineeassignment.services;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.traineeassignment.beans.LogIn;
import com.cg.traineeassignment.beans.TraineeRegister;
import com.cg.traineeassignment.dao.TraineeDao;

@Service("traineeServices")
public class TraineeServicesImpl implements TraineeServices {
	@Autowired
	TraineeDao traineeDao;

	public TraineeDao getTraineeDao() {
		return traineeDao;
	}

	public void setTraineeDao(TraineeDao traineeDao) {
		this.traineeDao = traineeDao;
	}

	@Override
	public boolean isUserExist(String userName,String password) {
		System.out.println("userName"+userName);
		if(userName.equals("aanchal") && password.equals("aanchal"))
			return true;
		else
		return false;
	}

	

	@Override
	public ArrayList<TraineeRegister> getAllUserDetails() {

		return traineeDao.getAllUserDetails();
	}


	@Override
	public TraineeRegister addTrainee(TraineeRegister register) {

		return traineeDao.addTrainee(register);
	}

	@Override
	public boolean deleteTrainee(int traineeId) {

		traineeDao.deleteTrainee(traineeId);
		return true;
	}

	@Override
	public TraineeRegister retrieveTrainee(int traineeId) {
		TraineeRegister register=	traineeDao.retrieveTrainee(traineeId);


		return register;
	}

	@Override
	public ArrayList<TraineeRegister> retrieveAllTrainee() {

		return traineeDao.retrieveAllTrainee();
	}

	@Override
	public TraineeRegister updateTrainee(TraineeRegister traineeRegister) {
		TraineeRegister register=	traineeDao.updateTrainee(traineeRegister);
		return traineeRegister;
	}



}

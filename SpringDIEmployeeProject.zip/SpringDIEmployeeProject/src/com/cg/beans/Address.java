package com.cg.beans;

public class Address {
	private String city,state;
	private long zipCode;
	
	
	
	
	public Address() {}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public long getZipCode() {
		return zipCode;
	}
	public void setZipCode(long zipCode) {
		this.zipCode = zipCode;
	}
	public Address(String city, String state, long zipCode) {
		super();
		this.city = city;
		this.state = state;
		this.zipCode = zipCode;
	}
	@Override
	public String toString() {
		return "city=" + city + ", state=" + state + ", zipCode=" + zipCode;
	}
	
	

}

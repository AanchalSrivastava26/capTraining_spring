package com.cg.beans;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestEmployeeDemo {
	public static void main(String[] args) {
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("cg.xml");
		Employee employee=(Employee)applicationContext.getBean("aanchalObject");
		System.out.println("---emp info---");
		System.out.println("ID :"+employee.getEmployeeId()+" "+"name :"+employee.getEmployeeName()+" "+"salary :"
		+employee.getEmployeeSalary()+" "+"address :"+employee.getAddress().getCity()+" "+employee.getAddress().getState()
		+" "+employee.getAddress().getZipCode());
		
		System.out.println("-----------------for arraylist of address--------------------");
		ApplicationContext applicationContext1=new ClassPathXmlApplicationContext("cg2.xml");
		Employee2 employee1=(Employee2)applicationContext1.getBean("aanchalObject");
		System.out.println("---emp info---");
		System.out.println("ID :"+employee1.getEmployeeId()+" "+"name :"+employee1.getEmployeeName()+" "+"salary :"
		+employee1.getEmployeeSalary()+" "+"address :"+employee1.getAddress());
	
	}

}

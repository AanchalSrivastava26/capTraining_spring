package com.cg.bean;

import java.util.Arrays;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="cg_userdetails")
public class Register {
	//@NotEmpty(message="user name mandatory")
	@Id
	@Column(name="user_name",length=25)
	private String userName;
	@Transient			//property which we do not want to map in db table is marked as transient
	private String password;
	@Transient
	private String confirmPassword;
	@NotEmpty(message="first name is mandatory")
	@Pattern(regexp="[A-Z][a-z]*",message="name should start with capital letters and"+"only characters are allowed")
	@Column(name="first_name",length=20)
	private String firstName;
	@Column(name="last_name",length=20)
	private String lastName;
	@Email(message="invalid email address")
	@Column(name="user_email",length=20)
	private String email;
	@Transient
	private String[] skillSet;
	@Column(name="user_skills",length=75)
	private String skillSetStr;
	@Column(name="user_gender",length=1)
	private char gender;
	@Column(name="user_city",length=15)
	private String city;

	public Register() {}

	public Register(String userName, String password, String confirmPassword, String firstName, String lastName,
			String email, String[] skillSet, char gender, String city) {
		super();
		this.userName = userName;
		this.password = password;
		this.confirmPassword = confirmPassword;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.skillSet = skillSet;
		this.gender = gender;
		this.city = city;
	}
	@NotEmpty(message="user name is required")
	@Size(min=5,message="size should be atleast 5")
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	@NotEmpty(message="password is required")
	@Size(min=5,message="size should be atleast 5")
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@NotEmpty(message="password is required")
	@Size(min=5,message="size should be atleast 5")
	public String getConfirmPassword() {
		return confirmPassword;
	}
	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String[] getSkillSet() {
		return skillSet;
	}
	public void setSkillSet(String[] skillSet) {

		this.skillSet = skillSet;
		setSkillSetStr(skillSet.toString());
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getSkillSetStr() {
		return skillSetStr;
	}
	public void setSkillSetStr(String skillSetStr) {
		this.skillSetStr = skillSetStr;
	}
	@Override
	public String toString() {
		return "userName=" + userName + ", password=" + password + ", confirmPassword=" + confirmPassword
				+ ", firstName=" + firstName + ", lastName=" + lastName + ", email=" + email + ", skillSet="
				+ Arrays.toString(skillSet) + ", gender=" + gender + ", city=" + city;
	}
}

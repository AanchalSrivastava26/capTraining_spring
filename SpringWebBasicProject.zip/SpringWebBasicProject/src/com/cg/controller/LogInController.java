package com.cg.controller;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.bean.LogIn;
import com.cg.bean.Register;
import com.cg.services.LoginService;

@Controller
public class LogInController {
	@Autowired																									//**to get rid of <property> element in xml configuration file
	LoginService loginSer;																					//injecting service into controller layer
	ArrayList<String> cityList=null;
	ArrayList<String> skillList=null;
	public LoginService getLoginSer() {
		return loginSer;
	}
	public void setLoginSer(LoginService loginSer) {
		this.loginSer = loginSer;
	}
	@RequestMapping(value="/logIn",method=RequestMethod.GET) // GET is used to retrieve data from server
	public String showMessage(Model model) {											//** logIn same as given in indexPage.jsp

		LogIn login=new LogIn();
		model.addAttribute("log",login);//(modelObjectname , modelobjectvalue)
		model.addAttribute("compNameObj","capgemini");//(key,value)-adding data with model
		return "LogIn";// login =view name
	}

	//validate user
	@RequestMapping(value="/ValidateUser" ,method=RequestMethod.POST)	//	POST is used when create/alter/delete operations are to be performed
	//**validateUser as given in LogIn.jsp in action

	public String validateUserDetails( @ModelAttribute(value="log")@Valid LogIn lg,BindingResult result,Model model) { //@modelattrribute because data is automatically going 
		//**log same as used as model attribute in LogIn.jsp
		//@valid-to check whether user has typed or not   BindingResult= if user has typed wrong msg will come to same page

		if(result.hasErrors()) {
			return "LogIn";

		}
		else {
			if(loginSer.isUserExist(lg.getUserName()))
			{
				LogIn user=loginSer.validateUser(lg);
				if(user!=null) {
					model.addAttribute("unmObj",lg.getUserName());
					return "Success";
				}
				else {

					return "Failure";
				}
			}
			else 
				return "redirect:/register.obj";
		}
	}
	//show register page
	@RequestMapping(value="/register", method=RequestMethod.GET)
	public String displayRegisterPage(Model model) {
		cityList=new ArrayList<>();
		cityList.add("lko");
		cityList.add("gzb");
		cityList.add("pune");
		cityList.add("mumbai");
		skillList=new ArrayList<>();
		skillList.add("java");
		skillList.add("dot net");
		skillList.add("oracle");
		skillList.add("html");
		skillList.add("python");
		Register register=new Register();
		model.addAttribute("reg",register);
		model.addAttribute("cityList",cityList);
		model.addAttribute("skillList",skillList);
		return "Register";
	}

	//insert user
	@RequestMapping(value="/InsertUser", method=RequestMethod.POST)
	public String addUserDetails(@ModelAttribute(value="reg") @Valid Register register,BindingResult result,Model model) {

		if(result.hasErrors()) {
			System.out.println("in error.."+register);
			model.addAttribute("cityList",cityList);
			model.addAttribute("skillList",skillList);
			return "Register";
		}
		else
		{
			System.out.println("no error.."+register);
			Register register1=	loginSer.insertUserDetails(register);
			ArrayList<Register> userList=loginSer.getAllUserDetails();
			model.addAttribute("userListObj",userList);
			//	model.addAttribute("RegObj",register1);
			return "ListAllUser";
		}

	}
	//****delete user
	@RequestMapping(value="/deleteUser",method=RequestMethod.GET)
	public String deleteUser(@RequestParam(value="uid") String unm,Model model) {
		Register register=loginSer.deleteUsers(unm);
		if(register!=null) {
			ArrayList<Register> userList=loginSer.getAllUserDetails();
			model.addAttribute("userListObj",userList);
			model.addAttribute("msgObj","data deleted");
			return "ListAllUser";
		}
		else
			return "Error";

	}
	@RequestMapping(value="/updateUser",method=RequestMethod.GET)
	public String updateUsers(@RequestParam(value="uid") String unm,Model model) {
		Register register=loginSer.updateUsers(unm);
		if(register!=null) {
			ArrayList<Register> userList=loginSer.getAllUserDetails();
			model.addAttribute("userListObj",userList);
			model.addAttribute("msgObj","data deleted");
			return "ListAllUser";
		}
		else
			return "Error";
		
	}
	
}


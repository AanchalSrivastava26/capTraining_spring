package com.cg.controller;

import java.time.LocalDate;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller  												 //controller component(specific type of component)
@RequestMapping("myController")
public class HelloController {
	@RequestMapping(value="/hello")
	public ModelAndView showMessage() {
		LocalDate today=LocalDate.now();
		ModelAndView modelAndView=new ModelAndView("Hello","tdObj",today);
		return modelAndView;
		
	}

}

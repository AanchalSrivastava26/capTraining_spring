package com.cg.services;

import java.util.ArrayList;

import com.cg.bean.LogIn;
import com.cg.bean.Register;

public interface LoginService {
	public boolean isUserExist(String uName);
	public LogIn validateUser(LogIn login);
	public Register insertUserDetails(Register userDetails);
	public ArrayList<Register> getAllUserDetails();
	public Register deleteUsers(String userName);
	public Register updateUsers(String userName);

}

package com.cg.staticdb;

import java.util.ArrayList;

import com.cg.bean.Country;

public  class CountryDB {
	private static ArrayList<Country> countryList=new ArrayList<Country>();

	public static ArrayList<Country> getCountryList() {
		return countryList;
	}
	public static void setCountryList(ArrayList<Country> countryList) {
		CountryDB.countryList = countryList;
	}
	static {
		countryList.add(new Country("1001", "India", "2137563"));
		countryList.add(new Country("1002", "Pakistan", "4732732"));
		countryList.add(new Country("1003", "SriLanka", "232382"));
		countryList.add(new Country("1004", "China", "7337563"));
		countryList.add(new Country("1005", "USA", "43137563"));
	}
}

package com.cg.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class EmployeeMainClass {

	public static void main(String[] args) {
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("cg.xml");
		Employee employee=(Employee)applicationContext.getBean("aanchalEmp");
		System.out.println(employee);
		System.out.println("--------------------for arraylist of address-----------------------");
		Employee2 employee1=(Employee2)applicationContext.getBean("employee2");
		System.out.println(employee1);
	}

}

package com.cg.bean;

public interface IGreet {
	public String greetMe();

}

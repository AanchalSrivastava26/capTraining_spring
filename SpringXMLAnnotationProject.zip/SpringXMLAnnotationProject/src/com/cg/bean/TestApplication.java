package com.cg.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestApplication {

	public static void main(String[] args) {
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("cg.xml");
		IGreet g1=(IGreet)applicationContext.getBean("obj1");
		System.out.println(g1.greetMe());
		System.out.println("------------------------------------");
		IGreet g2=(IGreet)applicationContext.getBean("obj2");
		System.out.println(g2.greetMe());


	}

}

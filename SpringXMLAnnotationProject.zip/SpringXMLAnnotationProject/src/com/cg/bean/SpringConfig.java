package com.cg.bean;

import java.util.ArrayList;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SpringConfig {
	@Bean
	public ArrayList<Address> getAddressList(){
		Address address=new Address();
		address.setCity("mumbai");
		address.setState("maharashtra");
		address.setZipCode(342644);
		
		Address address1=new Address();
		address1.setCity("Pune");
		address1.setState("maharashtra");
		address1.setZipCode(411057);
		
		
		ArrayList<Address> addressList=new ArrayList<Address>();
		addressList.add(address);
		addressList.add(address1);
		return addressList;
		
	}

}

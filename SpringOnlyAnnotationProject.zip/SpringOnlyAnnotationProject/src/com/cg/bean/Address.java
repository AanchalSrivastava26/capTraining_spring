package com.cg.bean;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("aanchalAddress")
public class Address {
	@Value("pune")
	private String city;
	@Value("maharashtra")
	private String state;
	@Value("411057")
	private long zipCode;

	public Address() {}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public long getZipCode() {
		return zipCode;
	}
	public void setZipCode(long zipCode) {
		this.zipCode = zipCode;
	}
	public Address(String city, String state, long zipCode) {
		super();
		this.city = city;
		this.state = state;
		this.zipCode = zipCode;
	}
	@Override
	public String toString() {
		return "city=" + city + ", state=" + state + ", zipCode=" + zipCode;
	}



}

package com.cg.bean;

import org.springframework.beans.factory.annotation.Value;

public class NewYearWish implements IGreet{
@Value("aanchal")
	private String firstName;
@Value("2019")
	private int year; 

	public NewYearWish(String firstName, int year) {
		super();
		this.firstName = firstName;
		this.year = year;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
		System.out.println("setFirstName called");
	}
	public NewYearWish() {
		System.out.println("New Year Wish");
	}

	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
		System.out.println("setYear called");
	}
	@Override
	public String greetMe() {

		return "Happy New Year"+" "+year+" "+firstName;
	}
}


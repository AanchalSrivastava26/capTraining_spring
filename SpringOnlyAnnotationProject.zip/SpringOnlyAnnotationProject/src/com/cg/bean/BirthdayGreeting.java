package com.cg.bean;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("obj2")
public class BirthdayGreeting implements IGreet,BeanNameAware,BeanFactoryAware,DisposableBean,InitializingBean{

@Value("prachi")
	private String firstName;

	public BirthdayGreeting(String firstName) {
		super();
		this.firstName = firstName;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
		System.out.println("setFirstName() called...");
	}
	public BirthdayGreeting() {
		System.out.println("in birthdayGreeting");
	}


	@Override
	public String greetMe() {

		return "happy birthday:"+firstName;
	}
	@Override
	public void setBeanName(String beanName) {
	System.out.println("in setBeanName() ..."+beanName);
		
	}
	@Override
	public void setBeanFactory(BeanFactory bf) throws BeansException {
		System.out.println("in setBeanFactory()..."+bf.toString());
		
	}
	@Override
	public void afterPropertiesSet() throws Exception {
	System.out.println("this is called after firstName set...");
	}
	@Override
	public void destroy() throws Exception {
		
		System.out.println("destroy is called...");
	}
	public void cgInit() {
		System.out.println("this is custom cg init");
	}
	public void cgDestroy() {
		System.out.println("this is custom cg destroy");
	}


}

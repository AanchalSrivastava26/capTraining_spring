package com.cg.bean;

import java.util.ArrayList;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

@Configuration
public class SpringConfig {
	@Bean
	public ArrayList<Address> getAddressList(){
		Address address=new Address();
		address.setCity("mumbai");
		address.setState("maharashtra");
		address.setZipCode(342644);
		
		Address address1=new Address();
		address1.setCity("Pune");
		address1.setState("maharashtra");
		address1.setZipCode(411057);
		
		
		ArrayList<Address> addressList=new ArrayList<Address>();
		addressList.add(address);
		addressList.add(address1);
		return addressList;
		

		
			
		}
	@Bean				//deleted cg.xml hence cofiguring that data here 
	public Address getAddress() {
		Address address2=new Address();
		address2.setCity("lucknow");
		address2.setState("up");
		address2.setZipCode(234132);
		return address2;
		
	}
	
	
	@Bean
	public static PropertySourcesPlaceholderConfigurer propertyConfigInDev() {
		return new PropertySourcesPlaceholderConfigurer();
		
	}

}

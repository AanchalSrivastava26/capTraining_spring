package com.cg.dao;
import java.util.List;

import com.cg.beans.Account;



public interface AccountDAO {
	Account save(Account account);
	boolean update(Account account);
	Account findOne(long accountNo);
	List<Account> findAll();
	
}
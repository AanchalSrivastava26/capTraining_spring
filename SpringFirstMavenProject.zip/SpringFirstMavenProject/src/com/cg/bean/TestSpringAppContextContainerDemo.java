package com.cg.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestSpringAppContextContainerDemo {

	public static void main(String[] args) {
	ApplicationContext applicationContext=new ClassPathXmlApplicationContext("cg.xml");
	IGreet g1=(IGreet)applicationContext.getBean("obj1");
	System.out.println(g1.greetMe());
	System.out.println(g1.hashCode());
	IGreet g2=(IGreet)applicationContext.getBean("obj1");
	System.out.println(g2.greetMe());
	System.out.println(g2.hashCode());//for singleton scope hashcodes for both references will be same and for prototype scope they are different. 
	}
}

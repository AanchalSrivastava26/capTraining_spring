package com.cg.bean;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class TestSpringXmlClientdemo {

	public static void main(String[] args) {
		//initializing bean factory container
		Resource resources=new ClassPathResource("cg.xml");
		BeanFactory beanFactory=new XmlBeanFactory(resources);
		System.out.println("------spring container initialized-----");
		IGreet birthdayGreet=(IGreet)beanFactory.getBean("obj1");
		IGreet birthdayGreet1=(IGreet)beanFactory.getBean("obj1");
		System.out.println(birthdayGreet.greetMe());
		System.out.println(birthdayGreet.hashCode());
		System.out.println(birthdayGreet1.hashCode());
		IGreet newYear=(IGreet)beanFactory.getBean("obj2");
		System.out.println(newYear.greetMe());
		System.out.println(newYear.hashCode());
		System.out.println("----constructor injection----");
		IGreet birthdayGreet2=(IGreet)beanFactory.getBean("obj4");
		System.out.println(birthdayGreet2.greetMe());
		System.out.println(birthdayGreet2.hashCode());
	}
}

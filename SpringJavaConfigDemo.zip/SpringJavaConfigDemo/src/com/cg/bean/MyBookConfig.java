package com.cg.bean;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

@Configuration
public class MyBookConfig {
	
	@Bean
	public Author author() {
		return new Author("aanchal", "lko");
		
	}
	@Bean(initMethod="setUp",destroyMethod="cleanUp")
	//@Scope("prototype")
	public Book book() {
		Book book=new Book();
	
		book.setYear("2019");
		book.setIsbn("hfe75437");
		book.setAuthor(author());
		return book;
	}

}

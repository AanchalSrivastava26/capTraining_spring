package com.cg.client;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.cg.bean.Book;
import com.cg.bean.MyBookConfig;

public class MainClass {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext ctx=new AnnotationConfigApplicationContext(MyBookConfig.class);
		Book book1=(Book)ctx.getBean("book");
		System.out.println("book hashcode :"+book1.hashCode());
		System.out.println("book info :"+book1);
		try {
			book1.cleanUp();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		ctx.close();
	}
}



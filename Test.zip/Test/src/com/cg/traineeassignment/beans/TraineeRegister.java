package com.cg.traineeassignment.beans;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;


@Entity
@Table(name="cg_traineeDetails")
public class TraineeRegister {
	@Id
	private int traineeId;
	//@NotEmpty(message="Trainee name is mandatory")
	//@Pattern(regexp="[A-Z][a-z]*",message="name should start with capital letters and"+" "+"only characters are allowed")
	@Column
	private String traineeName;
//	@NotEmpty(message="Trainee domain is required")
	@Column
	private String traineeDomain;
	//@NotEmpty(message="Trainee location is required")
	@Column
	private String traineeLocation;

	public TraineeRegister() {}

	public int getTraineeId() {
		return traineeId;
	}

	public void setTraineeId(int traineeId) {
		this.traineeId = traineeId;
	}

	public String getTraineeName() {
		return traineeName;
	}

	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}

	public String getTraineeDomain() {
		return traineeDomain;
	}
	public String getTraineeLocation() {
		return traineeLocation;
	}

	public void setTraineeLocation(String traineeLocation) {
		this.traineeLocation = traineeLocation;
	}

	public void setTraineeDomain(String traineeDomain) {
		this.traineeDomain = traineeDomain;
	}

	@Override
	public String toString() {
		return "traineeId=" + traineeId + ", traineeName=" + traineeName + ", traineeDomain=" + traineeDomain
				+ ", traineeLocation=" +traineeLocation;
	}
}

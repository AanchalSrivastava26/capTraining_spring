package com.cg.traineeassignment.beans;



public class Revision {

	public static void main(String[] args) {
		String str = new String("PACE");
		String str1 = str;
		str=null;
		System.out.println("Length of the string is :" + str1.length());

	}

}

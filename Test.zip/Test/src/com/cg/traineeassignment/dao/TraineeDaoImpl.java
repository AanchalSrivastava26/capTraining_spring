package com.cg.traineeassignment.dao;

import java.util.ArrayList;



import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.traineeassignment.beans.LogIn;
import com.cg.traineeassignment.beans.TraineeRegister;


@Repository																// @Repository= indicate that the class provides storage, retrieval, search, update and delete operation on objects.
@Transactional		
public class TraineeDaoImpl implements TraineeDao{

	@PersistenceContext																	//annotation used to inject EntityManager
	EntityManager entityManager=null;

	public EntityManager getEntityManager() {
		return entityManager;
	}
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}


	@Override
	public boolean isUserExist(String uName) {

		LogIn user=entityManager.find(LogIn.class, uName);
		if(user!=null)
			return true;
		else
			return false;
	}


	@Override
	public LogIn validateUser(LogIn login) {

		LogIn user=entityManager.find(LogIn.class, login.getUserName());
		return user;

	}



	@Override
	public ArrayList<TraineeRegister> getAllUserDetails() {

		String query="SELECT reg FROM TraineeRegister reg";
		TypedQuery typeQuery=entityManager.createQuery(query,TraineeRegister.class);
		ArrayList<TraineeRegister> uList=(ArrayList)typeQuery.getResultList();
		return uList;
	}


	@Override
	public TraineeRegister addTrainee(TraineeRegister register) {
		entityManager.persist(register);
		return register;
	}
	@Override
	public boolean deleteTrainee(int traineeId) {
 
		TraineeRegister register=entityManager.find(TraineeRegister.class, traineeId);
		System.out.println("Detailsssssssssssss:"+register);
		entityManager.remove(register);
		entityManager.flush();

		return true;
	}
	@Override
	public TraineeRegister retrieveTrainee(int traineeId) {
		TraineeRegister register=entityManager.find(TraineeRegister.class, traineeId);
		
		
		return register ;
	}
	@Override
	public ArrayList<TraineeRegister> retrieveAllTrainee() {
	
		return (ArrayList<TraineeRegister>) entityManager.createQuery("from TraineeRegister r").getResultList();
	}
	@Override
	public TraineeRegister updateTrainee(TraineeRegister traineeRegister) {
	TraineeRegister traineeRegister2=entityManager.merge(traineeRegister);
		return traineeRegister2;
	}


}

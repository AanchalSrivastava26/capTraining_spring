package com.cg.dao;

import java.util.ArrayList;


import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.bean.Register;

@Repository("loginDao")																// @Repository= indicate that the class provides storage, retrieval, search, update and delete operation on objects.
@Transactional																					//automatically performs begin and commit
public class LoginDAOImpl implements LoginDAO{

	@PersistenceContext																	//annotation used to inject EntityManager
	EntityManager entityManager=null;

	public EntityManager getEntityManager() {
		return entityManager;
	}
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}
/*
	@Override
	public boolean isUserExist(String uName) {
		LogIn user=entityManager.find(LogIn.class, uName);
		if(user!=null)
			return true;
		else
			return false;
	}

	@Override
	public LogIn validateUser(LogIn login) {
		LogIn user=entityManager.find(LogIn.class, login.getUserName());
		return user;
	}*/
	@Override
	public Register insertUserDetails(Register userDetails) {


	
		entityManager.persist(userDetails);
	//	entityManager.persist(logIn);
		entityManager.flush();
		Register register=entityManager.find(Register.class, userDetails.getUserId());
		return register;
	}
	@Override
	public ArrayList<Register> getAllUserDetails() {
		String query="SELECT reg FROM Register reg";
		TypedQuery typeQuery=entityManager.createQuery(query,Register.class);
		ArrayList<Register> uList=(ArrayList)typeQuery.getResultList();
		return uList;
	}/*
	//delete users
	@Override
	public Register deleteUsers(String userName) {
		Register register=entityManager.find(Register.class, userName);
		LogIn logIn=entityManager.find(LogIn.class, userName);
		entityManager.remove(register);
		entityManager.remove(logIn);
		entityManager.flush();
		
		return register;
	}
	@Override
	public Register updateUsers(String userName) {
		Register register=entityManager.find(Register.class, userName);
		LogIn logIn=entityManager.find(LogIn.class, userName);
		entityManager.merge(register);
		entityManager.merge(logIn);
		return register;
	}*/

}

package com.cg.services;

import java.util.ArrayList;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Register;
import com.cg.dao.LoginDAO;

@Service("loginSer")
public class LoginServiceImpl implements LoginService{
	@Autowired
	LoginDAO loginDao=null;

	public LoginDAO getLoginDao() {
		return loginDao;
	}
	public void setLoginDao(LoginDAO loginDao) {
		this.loginDao = loginDao;
	}
/*
	@Override
	public LogIn validateUser(LogIn login) {
		LogIn dbUser=loginDao.validateUser(login);

		if(login.getUserName().equalsIgnoreCase(dbUser.getUserName()) && login.getPassword().equalsIgnoreCase(dbUser.getPassword()))
			return login;
		else 
			return null;
	}

	@Override
	public boolean isUserExist(String uName) {

		return loginDao.isUserExist(uName);
	}*/
	@Override
	public Register insertUserDetails(Register userDetails) {
	
		return loginDao.insertUserDetails(userDetails);
	}
	@Override
	public ArrayList<Register> getAllUserDetails() {
		
		return loginDao.getAllUserDetails();
	}
	/*
	@Override
	public Register deleteUsers(String userName) {

		return loginDao.deleteUsers(userName);
	}
	@Override
	public Register updateUsers(String userName) {
		
		return loginDao.updateUsers(userName);
	}*/
}
